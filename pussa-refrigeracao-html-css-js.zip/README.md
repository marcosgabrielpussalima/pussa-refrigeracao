# Pussa Refrigeração — versão estática

Site convertido para HTML + CSS + JavaScript puro.

Arquivos:
- index.html
- style.css
- script.js

Não há React, TypeScript, Vite, Tailwind, Node.js ou bibliotecas JS necessárias.

Para testar:
1. Abra `index.html` no navegador; ou
2. No terminal, dentro da pasta: `python3 -m http.server 8000`
3. Acesse `http://localhost:8000`

Observação:
O ZIP original não continha os arquivos de imagem referenciados pelo projeto React (`/manus-storage/...`). Por isso, esta versão mantém o visual e a identidade usando ilustrações e elementos locais em HTML/CSS, sem imagens externas obrigatórias.
